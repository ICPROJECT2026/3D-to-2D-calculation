import cv2
import numpy as np

# ========= 用户参数 =========
image_path = "/Users/jin/Desktop/table.jpg"   # 改成你的图片路径
table_width = 100.0        # 桌面实际宽度，例如 100 cm
table_height = 60.0        # 桌面实际高度，例如 60 cm

corner_points = []
object_points = []
H = None

# 读取图像
img = cv2.imread(image_path)
if img is None:
    raise FileNotFoundError(f"Cannot load image: {image_path}")

img_display = img.copy()

def redraw_image():
    global img_display
    img_display = img.copy()

    # 画桌角
    for i, pt in enumerate(corner_points):
        cv2.circle(img_display, tuple(pt), 6, (0, 255, 0), -1)
        cv2.putText(img_display, f"C{i+1}", (pt[0] + 10, pt[1] - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # 如果已经有4个角，画桌面边框
    if len(corner_points) == 4:
        pts = np.array(corner_points, dtype=np.int32)
        cv2.polylines(img_display, [pts], isClosed=True, color=(255, 0, 0), thickness=2)

    # 画目标点
    for idx, pt in enumerate(object_points):
        x, y = pt
        cv2.circle(img_display, (x, y), 6, (0, 0, 255), -1)
        cv2.putText(img_display, f"P{idx+1}", (x + 10, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

        # 如果已经有映射矩阵，显示转换后的坐标
        if H is not None:
            obj_pt = np.array([[[x, y]]], dtype=np.float32)
            mapped_pt = cv2.perspectiveTransform(obj_pt, H)
            x_real, y_real = mapped_pt[0][0]
            text = f"({x_real:.1f}, {y_real:.1f})"
            cv2.putText(img_display, text, (x + 10, y + 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 255), 2)

def compute_homography():
    global H
    if len(corner_points) == 4:
        src_pts = np.array(corner_points, dtype=np.float32)
        dst_pts = np.array([
            [0, 0],
            [table_width, 0],
            [table_width, table_height],
            [0, table_height]
        ], dtype=np.float32)

        H = cv2.getPerspectiveTransform(src_pts, dst_pts)
        print("\nHomography matrix computed successfully.")
        print("Now you can keep clicking object points.")
        print("Press 'r' to clear object points, 'c' to reset all, 'q' to quit.\n")

def mouse_callback(event, x, y, flags, param):
    global corner_points, object_points

    if event == cv2.EVENT_LBUTTONDOWN:
        # 先选4个桌角
        if len(corner_points) < 4:
            corner_points.append([x, y])
            print(f"Corner {len(corner_points)}: ({x}, {y})")

            if len(corner_points) == 4:
                compute_homography()

        else:
            # 后续点击作为目标点，可重复
            object_points.append([x, y])

            if H is not None:
                obj_pt = np.array([[[x, y]]], dtype=np.float32)
                mapped_pt = cv2.perspectiveTransform(obj_pt, H)
                x_real, y_real = mapped_pt[0][0]

                print(f"Point {len(object_points)} pixel: ({x}, {y})")
                print(f" -> Table coordinate: ({x_real:.2f}, {y_real:.2f})")
                print(f" -> Distance to left edge: {x_real:.2f}")
                print(f" -> Distance to top edge: {y_real:.2f}\n")

        redraw_image()

# 创建窗口
cv2.namedWindow("Table Mapping")
cv2.setMouseCallback("Table Mapping", mouse_callback)

print("Instructions:")
print("1. Click the 4 corners of the table in this order:")
print("   top-left -> top-right -> bottom-right -> bottom-left")
print("2. After that, keep clicking object points.")
print("3. Press 'r' to clear object points.")
print("4. Press 'c' to reset everything.")
print("5. Press 'q' to quit.\n")

while True:
    cv2.imshow("Table Mapping", img_display)
    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif key == ord('r'):
        object_points = []
        print("Object points cleared.\n")
        redraw_image()

    elif key == ord('c'):
        corner_points = []
        object_points = []
        H = None
        print("All points reset. Please reselect the 4 table corners.\n")
        redraw_image()

cv2.destroyAllWindows()
