import cv2
import numpy as np

depth = cv2.imread("fake_depth.png", cv2.IMREAD_UNCHANGED)

if depth is None:
    print("没读到 fake_depth.png")
else:
    print("depth shape:", depth.shape)
    print("depth dtype:", depth.dtype)

    h, w = depth.shape

    fx = 500.0
    fy = 500.0
    cx = w / 2.0
    cy = h / 2.0

    points = []

    for y in range(h):
        for x in range(w):
            Z = float(depth[y, x])

            if Z == 0:
                continue

            X = (x - cx) * Z / fx
            Y = (y - cy) * Z / fy

            points.append([X, Y, Z])

    points = np.array(points, dtype=np.float32)

    print("点的数量:", len(points))
    print("前 10 个点:")
    print(points[:10])
