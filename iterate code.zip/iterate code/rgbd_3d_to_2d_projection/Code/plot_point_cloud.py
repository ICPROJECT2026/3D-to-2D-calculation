import cv2
import numpy as np
import matplotlib.pyplot as plt

depth = cv2.imread("fake_depth.png", cv2.IMREAD_UNCHANGED)

if depth is None:
    print("没读到 fake_depth.png")
else:
    h, w = depth.shape

    fx = 500.0
    fy = 500.0
    cx = w / 2.0
    cy = h / 2.0

    points = []

    # 不要每个点都画，太多了
    step = 10

    for y in range(0, h, step):
        for x in range(0, w, step):
            Z = float(depth[y, x])

            if Z == 0:
                continue

            X = (x - cx) * Z / fx
            Y = (y - cy) * Z / fy

            points.append([X, Y, Z])

    points = np.array(points, dtype=np.float32)

    print("采样后的点数:", len(points))

    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection="3d")

    ax.scatter(points[:, 0], points[:, 1], points[:, 2], s=2, c=points[:, 2], cmap="jet")

    ax.set_title("Fake Depth Point Cloud")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")

    plt.show()
