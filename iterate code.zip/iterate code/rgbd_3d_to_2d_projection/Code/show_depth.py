import numpy as np
import cv2
import matplotlib.pyplot as plt

# 造一张假的深度图：高 300，宽 500
h, w = 300, 500

# 从左到右，深度值逐渐变大
depth = np.tile(np.linspace(0, 5000, w, dtype=np.uint16), (h, 1))

print("shape:", depth.shape)
print("dtype:", depth.dtype)
print("min:", depth.min())
print("max:", depth.max())

# 保存成 png
cv2.imwrite("fake_depth.png", depth)

# 显示
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.imshow(depth, cmap="gray")
plt.title("Fake Depth Gray")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(depth, cmap="jet")
plt.title("Fake Depth Color")
plt.axis("off")

plt.tight_layout()
plt.show()
