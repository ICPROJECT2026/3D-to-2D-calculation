import cv2
import matplotlib.pyplot as plt

# 读 RGB 图
rgb = cv2.imread("rgb.jpg")

# 读第二张图
depth = cv2.imread("depth.png", cv2.IMREAD_UNCHANGED)

if rgb is None:
    print("没读到 rgb.jpg")
elif depth is None:
    print("没读到 depth.png")
else:
    # OpenCV 读彩色图默认是 BGR，显示前转成 RGB
    rgb_show = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)

    plt.figure(figsize=(10, 4))

    plt.subplot(1, 2, 1)
    plt.imshow(rgb_show)
    plt.title("RGB")
    plt.axis("off")

    plt.subplot(1, 2, 2)
    if len(depth.shape) == 2:
        plt.imshow(depth, cmap="gray")
    else:
        depth_show = cv2.cvtColor(depth, cv2.COLOR_BGR2RGB)
        plt.imshow(depth_show)
    plt.title("Depth / Second Image")
    plt.axis("off")

    plt.tight_layout()
    plt.show()
