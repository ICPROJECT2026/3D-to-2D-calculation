import cv2
import matplotlib.pyplot as plt

rgb = cv2.imread("rgb.jpg")
depth = cv2.imread("fake_depth.png", cv2.IMREAD_UNCHANGED)

if rgb is None:
    print("没读到 rgb.jpg")
elif depth is None:
    print("没读到 fake_depth.png")
else:
    rgb_show = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)

    h, w = depth.shape

    # 假设一组简单内参
    fx = 500.0
    fy = 500.0
    cx = w / 2.0
    cy = h / 2.0

    print("fx =", fx)
    print("fy =", fy)
    print("cx =", cx)
    print("cy =", cy)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].imshow(rgb_show)
    axes[0].set_title("RGB")
    axes[0].axis("off")

    axes[1].imshow(depth, cmap="jet")
    axes[1].set_title("Click Depth Image")
    axes[1].axis("off")

    current_point = {"plot": None, "text": None}

    def onclick(event):
        if event.inaxes == axes[1] and event.xdata is not None and event.ydata is not None:
            x = int(event.xdata)
            y = int(event.ydata)
            Z = float(depth[y, x])

            X = (x - cx) * Z / fx
            Y = (y - cy) * Z / fy

            print(f"pixel=({x}, {y}), depth={Z}")
            print(f"3D = ({X:.2f}, {Y:.2f}, {Z:.2f})")

            if current_point["plot"] is not None:
                current_point["plot"].remove()
            if current_point["text"] is not None:
                current_point["text"].remove()

            current_point["plot"] = axes[1].plot(x, y, "wo")[0]
            current_point["text"] = axes[1].text(
                x, y,
                f"Z={Z:.0f}",
                color="white",
                fontsize=10,
                backgroundcolor="black"
            )

            fig.canvas.draw()

    fig.canvas.mpl_connect("button_press_event", onclick)
    plt.tight_layout()
    plt.show()
