import cv2
import numpy as np
import matplotlib.pyplot as plt

rgb = cv2.imread("rgb.jpg")
depth = cv2.imread("fake_depth.png", cv2.IMREAD_UNCHANGED)

if rgb is None:
    print("没读到 rgb.jpg")
elif depth is None:
    print("没读到 fake_depth.png")
else:
    print("rgb shape:", rgb.shape)
    print("rgb dtype:", rgb.dtype)
    print("depth shape:", depth.shape)
    print("depth dtype:", depth.dtype)
    print("depth min:", np.min(depth))
    print("depth max:", np.max(depth))

    rgb_show = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)

    plt.figure(figsize=(12, 4))

    plt.subplot(1, 3, 1)
    plt.imshow(rgb_show)
    plt.title("RGB")
    plt.axis("off")

    plt.subplot(1, 3, 2)
    plt.imshow(depth, cmap="gray")
    plt.title("Fake Depth Gray")
    plt.axis("off")

    plt.subplot(1, 3, 3)
    plt.imshow(depth, cmap="jet")
    plt.title("Fake Depth Color")
    plt.axis("off")

    plt.tight_layout()
    plt.show()
